import express from "express";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.GEMINI_API_KEY) {
  console.warn("Warning: GEMINI_API_KEY is not configured. Copy .env.example to .env and add your key.");
}

const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY })
  : null;

app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history = [] } = req.body || {};

    if (!message || typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ error: "Please enter a message." });
    }

    if (!ai) {
      return res.status(500).json({
        error: "Gemini API key is not configured. Add GEMINI_API_KEY to your .env file."
      });
    }

    const contents = [
      ...history.slice(-12).map((item) => ({
        role: item.role === "assistant" ? "model" : "user",
        parts: [{ text: String(item.text || "") }]
      })),
      { role: "user", parts: [{ text: message.trim() }] }
    ];

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents,
      config: {
        systemInstruction:
          "You are Gemini AI Assistant, a helpful, accurate, friendly assistant. " +
          "Explain answers clearly and use concise formatting when appropriate."
      }
    });

    res.json({ reply: response.text || "I couldn't generate a response." });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: error?.message || "Something went wrong while contacting Gemini."
    });
  }
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.GEMINI_API_KEY) });
});

app.listen(port, () => {
  console.log(`Gemini AI Assistant running at http://localhost:${port}`);
});
