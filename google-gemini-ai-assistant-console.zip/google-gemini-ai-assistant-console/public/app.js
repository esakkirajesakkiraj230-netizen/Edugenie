const chat = document.getElementById("chat");
const form = document.getElementById("chatForm");
const input = document.getElementById("message");
const send = document.getElementById("send");
const newChat = document.getElementById("newChat");
let history = [];

function addMessage(role, text) {
  const row = document.createElement("div");
  row.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "You" : "✦";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  row.append(avatar, bubble);
  chat.appendChild(row);
  chat.scrollTop = chat.scrollHeight;
}

function clearWelcome() {
  const welcome = chat.querySelector(".welcome");
  if (welcome) welcome.remove();
}

async function sendMessage(text) {
  clearWelcome();
  addMessage("user", text);
  input.value = "";
  send.disabled = true;

  const loading = document.createElement("div");
  loading.className = "message assistant";
  loading.innerHTML = '<div class="avatar">✦</div><div class="bubble">Thinking…</div>';
  chat.appendChild(loading);
  chat.scrollTop = chat.scrollHeight;

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, history })
    });
    const data = await response.json();
    loading.remove();

    if (!response.ok) throw new Error(data.error || "Request failed");

    addMessage("assistant", data.reply);
    history.push({ role: "user", text }, { role: "assistant", text: data.reply });
  } catch (error) {
    loading.remove();
    addMessage("assistant", `Error: ${error.message}`);
  } finally {
    send.disabled = false;
    input.focus();
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const text = input.value.trim();
  if (text && !send.disabled) sendMessage(text);
});

input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

newChat.addEventListener("click", () => {
  history = [];
  chat.innerHTML = `<div class="welcome">
    <div class="welcome-icon">✦</div>
    <h3>How can I help you?</h3>
    <p>Try asking a question, explaining a topic, or generating ideas.</p>
    <div class="suggestions">
      <button>Explain artificial intelligence simply</button>
      <button>Help me build a study plan</button>
      <button>Write a Python program for a calculator</button>
    </div>
  </div>`;
  bindSuggestions();
  input.focus();
});

function bindSuggestions() {
  document.querySelectorAll(".suggestions button").forEach((button) => {
    button.onclick = () => sendMessage(button.textContent);
  });
}
bindSuggestions();
