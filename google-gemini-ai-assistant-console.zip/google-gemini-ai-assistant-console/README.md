# Google Gemini AI Assistant Console

A simple full-stack Gemini AI Assistant console using Node.js, Express, and the official `@google/genai` JavaScript SDK.

## Features

- Modern chat-style web console
- Google Gemini API integration
- Conversation history sent with recent messages
- Loading/error states
- Responsive design
- API key stored in `.env`, not in frontend code
- Health endpoint at `/api/health`

## Requirements

- Node.js 18+
- A Gemini API key from Google AI Studio

## Setup

1. Extract this ZIP.
2. Open a terminal in the project folder.
3. Install dependencies:

```bash
npm install
```

4. Copy `.env.example` to `.env`.
5. Put your Gemini API key in `.env`:

```env
GEMINI_API_KEY=your_key_here
PORT=3000
```

6. Start the project:

```bash
npm start
```

7. Open:

http://localhost:3000

## Development

```bash
npm run dev
```

## Important

Never commit or publish your `.env` file. The `.gitignore` file already excludes it.

The project uses Google's official JavaScript Gemini SDK (`@google/genai`) and the `gemini-3.8-flash` model shown in the current Gemini API documentation.
